A Pen created at CodePen.io. You can find this one at https://codepen.io/khadkamhn/pen/pJLdBp.

 Material Music Player is based on HTML5, CSS3 and jQuery. During creating this player I had make a lot of fun :)